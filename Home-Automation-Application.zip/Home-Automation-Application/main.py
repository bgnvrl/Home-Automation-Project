import os
import time
from home_automation_api import AirConditionerSystemConnection, CurtainControlSystemConnection

# --- PORT AYARLARI ---
# PC tarafi icin portlar:
BOARD1_PORT = 1  # (PC COM1 <-> VSPE <-> PIC COM2)
BOARD2_PORT = 5  # (PC COM5 <-> VSPE <-> PIC COM6)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    # --- NESNELERI OLUSTUR ---
    ac_system = AirConditionerSystemConnection()
    curtain_system = CurtainControlSystemConnection()
    
    # --- AYARLARI YAP ---
    ac_system.setComPort(BOARD1_PORT)
    ac_system.setBaudRate(9600)
    
    curtain_system.setComPort(BOARD2_PORT)
    curtain_system.setBaudRate(9600)

    # --- BAGLANTILARI AC ---
    print(f"Connecting to Board #1 (AC) on COM{BOARD1_PORT}...")
    if ac_system.open():
        print(">> Board #1 Connected.")
    else:
        print(">> Board #1 Connection FAILED.")

    print(f"Connecting to Board #2 (Curtain) on COM{BOARD2_PORT}...")
    if curtain_system.open():
        print(">> Board #2 Connected.")
    else:
        print(">> Board #2 Connection FAILED.")
    
    time.sleep(2)

    # --- ANA MENU DONGUSU ---
    while True:
        clear_screen()
        print("====== MAIN MENU ======")
        print("1. Air Conditioner")
        print("2. Curtain Control")
        print("3. Exit")
        print("=======================")
        
        choice = input("Select: ")

        # --- 1. AIR CONDITIONER MENU ---
        if choice == '1':
            while True:
                ac_system.update() # Veri Cek
                
                clear_screen()
                print("--- Air Conditioner Control ---")
                print(f"Home Ambient Temperature: {ac_system.getAmbientTemp()} C")
                print(f"Home Desired Temperature: {ac_system.getDesiredTemp()} C")
                print(f"Fan Speed:                {ac_system.getFanSpeed()} rps")
                print("-------------------------------")
                print(f"Connection: COM{BOARD1_PORT} | 9600 baud")
                print("-------------------------------")
                print("MENU")
                print("1. Enter the desired temperature")
                print("2. Return")
                
                sub = input("Select: ")
                
                if sub == '1':
                    try:
                        val = float(input("Enter Desired Temp: "))
                        if ac_system.setDesiredTemp(val):
                            print(">> Command Sent.")
                        else:
                            print(">> Error sending command.")
                        time.sleep(1)
                    except ValueError: pass
                elif sub == '2': break

        # --- 2. CURTAIN CONTROL MENU [YENI] ---
        elif choice == '2':
            while True:
                curtain_system.update() # Veri Cek
                
                clear_screen()
                print("--- Curtain Control ---")
                print(f"Outdoor Temperature: {curtain_system.getOutdoorTemp()} C")
                print(f"Outdoor Pressure:    {curtain_system.getOutdoorPress()} hPa")
                print(f"Curtain Status:      {curtain_system.curtainStatus} %")
                print(f"Light Intensity:     {curtain_system.getLightIntensity()} Lux")
                print("-----------------------")
                print(f"Connection: COM{BOARD2_PORT} | 9600 baud")
                print("-----------------------")
                print("MENU")
                print("1. Enter the desired curtain status")
                print("2. Return")
                
                sub = input("Select: ")
                
                if sub == '1':
                    try:
                        val = float(input("Enter Curtain % (0-100): "))
                        if 0 <= val <= 100:
                            if curtain_system.setCurtainStatus(val):
                                print(">> Command Sent (Motor Moving...).")
                            else:
                                print(">> Error sending command.")
                        else:
                            print(">> Please enter 0-100.")
                        time.sleep(1.5)
                    except ValueError: pass
                elif sub == '2': break

        # --- 3. EXIT ---
        elif choice == '3':
            ac_system.close()
            curtain_system.close()
            print("Exiting...")
            break

if __name__ == "__main__":
    main()