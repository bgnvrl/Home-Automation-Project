import serial
import time

# ==========================================
# [R2.3-1] API Implementation based on UML
# ==========================================

class HomeAutomationSystemConnection:
    def __init__(self):
        self.comPort = 0
        self.baudRate = 9600
        self.serialConn = None

    def setComPort(self, port: int):
        self.comPort = port

    def setBaudRate(self, rate: int):
        self.baudRate = rate

    def open(self) -> bool:
        try:
            port_name = f"COM{self.comPort}"
            self.serialConn = serial.Serial(
                port=port_name,
                baudrate=self.baudRate,
                timeout=1
            )
            return True
        except Exception as e:
            print(f"Connection Error ({port_name}): {e}")
            return False

    def close(self) -> bool:
        if self.serialConn and self.serialConn.is_open:
            self.serialConn.close()
            return True
        return False

    def update(self):
        pass

    def _send_byte(self, byte_val):
        if self.serialConn and self.serialConn.is_open:
            try:
                self.serialConn.write(bytes([byte_val]))
                time.sleep(0.05)
            except: pass

    def _read_byte(self) -> int:
        if self.serialConn and self.serialConn.is_open:
            try:
                val = self.serialConn.read(1)
                if val:
                    return int.from_bytes(val, byteorder='big')
            except: pass
        return 0

# --- Board #1 Class (Klima) ---
class AirConditionerSystemConnection(HomeAutomationSystemConnection):
    def __init__(self):
        super().__init__()
        self.desiredTemperature = 0.0
        self.ambientTemperature = 0.0
        self.fanSpeed = 0

    def update(self):
        # 1. Ambient Temp
        self._send_byte(0x04)
        temp_int = self._read_byte()
        self._send_byte(0x03)
        temp_frac = self._read_byte()
        self.ambientTemperature = float(f"{temp_int}.{temp_frac}")

        # 2. Desired Temp
        self._send_byte(0x02)
        des_int = self._read_byte()
        self._send_byte(0x01)
        des_frac = self._read_byte()
        self.desiredTemperature = float(f"{des_int}.{des_frac}")
        
        # 3. Fan Speed
        self._send_byte(0x05)
        self.fanSpeed = self._read_byte()

    def setDesiredTemp(self, temp: float) -> bool:
        try:
            val_int = int(temp)
            cmd_int = 0xC0 | (val_int & 0x3F) 
            self._send_byte(cmd_int)
            self.desiredTemperature = temp
            return True
        except:
            return False

    def getAmbientTemp(self) -> float: return self.ambientTemperature
    def getFanSpeed(self) -> int: return self.fanSpeed
    def getDesiredTemp(self) -> float: return self.desiredTemperature

# --- Board #2 Class (Perde) [YENI EKLENDI] ---
class CurtainControlSystemConnection(HomeAutomationSystemConnection):
    def __init__(self):
        super().__init__()
        # UML'deki degiskenler
        self.curtainStatus = 0.0      # float
        self.outdoorTemperature = 0.0 # float
        self.outdoorPressure = 0.0    # float
        self.lightIntensity = 0.0     # double (python'da float)

    def update(self):
        """
        [Member Function] Gets all data from Board #2
        """
        # 1. Curtain Status (Perde Durumu)
        self._send_byte(0x02) # Get Int
        curt_int = self._read_byte()
        self._send_byte(0x01) # Get Frac
        curt_frac = self._read_byte() 
        self.curtainStatus = float(f"{curt_int}.{curt_frac}")

        # 2. Outdoor Temperature (Dis Sicaklik)
        self._send_byte(0x04)
        temp_int = self._read_byte()
        self._send_byte(0x03)
        temp_frac = self._read_byte()
        self.outdoorTemperature = float(f"{temp_int}.{temp_frac}")

        # 3. Outdoor Pressure (Basinc - 16 Bit)
        self._send_byte(0x06) # High Byte
        press_h = self._read_byte()
        self._send_byte(0x05) # Low Byte
        press_l = self._read_byte()
        # Iki byte'i birlestir (High << 8 | Low)
        self.outdoorPressure = float((press_h << 8) | press_l)

        # 4. Light Intensity (Isik)
        self._send_byte(0x10) 
        light_h = self._read_byte()
        self.lightIntensity = float(light_h) 

    def setCurtainStatus(self, status: float) -> bool:
        """
        [Member Function] Set curtain status (0-100%)
        """
        try:
            val_int = int(status)
            # Protokol: 11xxxxxx (0xC0 maskesi)
            cmd_int = 0xC0 | (val_int & 0x3F)
            self._send_byte(cmd_int)
            
            self.curtainStatus = status
            return True
        except:
            return False

    # --- Getter Functions ---
    def getCurtainStatus(self) -> float: return self.curtainStatus # Ekstra getter
    def getOutdoorTemp(self) -> float: return self.outdoorTemperature
    def getOutdoorPress(self) -> float: return self.outdoorPressure
    def getLightIntensity(self) -> float: return self.lightIntensity